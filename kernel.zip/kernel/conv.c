#include "conv.h"

typedef unsigned long long int size_t;
uint64_t* CONV_BASE = (uint64_t*)0x10001000L;
const size_t CONV_KERNEL_OFFSET = 0;
const size_t CONV_DATA_OFFSET = 1;
const size_t CONV_RESULT_LO_OFFSET = 0;
const size_t CONV_RESULT_HI_OFFSET = 1;
const size_t CONV_STATE_OFFSET = 2;
const unsigned char READY_MASK = 0b01;
const size_t CONV_ELEMENT_LEN = 4;

uint64_t* MISC_BASE = (uint64_t*)0x10002000L;
const size_t MISC_TIME_OFFSET = 0;

uint64_t get_time(void) {
    return MISC_BASE[MISC_TIME_OFFSET];
}

void conv_compute(const uint64_t* data_array, size_t data_len, const uint64_t* kernel_array, size_t kernel_len, uint64_t* dest) {
    for (size_t i = 0; i < kernel_len; ++i) {
        CONV_BASE[CONV_KERNEL_OFFSET] = kernel_array[i];
    }

    for (size_t i = 0; i < data_len+6; ++i) {
	if(i<3)
	{
	    CONV_BASE[CONV_DATA_OFFSET] = 0;
	}
	else if(i>data_len+2)
	{
	    CONV_BASE[CONV_DATA_OFFSET] = 0;
	        while ((CONV_BASE[CONV_STATE_OFFSET] & READY_MASK) == 0);
        	dest[((i-3)<<1)+1] = CONV_BASE[CONV_RESULT_LO_OFFSET]; 
        	dest[(i-3)<<1] = CONV_BASE[CONV_RESULT_HI_OFFSET];
	}
	else 
	{
	    CONV_BASE[CONV_DATA_OFFSET] = data_array[i-3];
	        while ((CONV_BASE[CONV_STATE_OFFSET] & READY_MASK) == 0);
        	dest[((i-3)<<1)+1] = CONV_BASE[CONV_RESULT_LO_OFFSET]; 
        	dest[((i-3)<<1)] = CONV_BASE[CONV_RESULT_HI_OFFSET];
	}     
    }
    
}

void mul64 (uint64_t a, uint64_t b, uint64_t* hi, uint64_t *lo)
{
    uint64_t hi_num = 0, lo_num = 0, lo_numtemp = 0;
    uint64_t carry = 0;
    for (int i = 0; i < 64; ++i) {
        lo_numtemp = lo_num + ((a&1)? (b<<i) : 0);
        if(lo_numtemp < lo_num)carry = 1;
        else carry = 0;
        if(i==63)
        {
        	if((b<<i&1)&&(lo_numtemp>>63))
        	carry = 1;
	}
        if(i>0)hi_num += (a&1)? (b>>(64-i)): 0;
        lo_num += (a&1)? (b<<i) : 0;
        hi_num += carry;
        a>>=1;
    }

    *hi = hi_num;
    *lo = lo_num;
}
void mul_compute(const uint64_t* data_array, size_t data_len, const uint64_t* kernel_array, size_t kernel_len, uint64_t* dest) {
	
    uint64_t data[4] = {0};
    uint64_t hi[4] = {0};
    uint64_t lo[4] = {0};
    uint64_t res_hi, res_lo;
    for(int i=0; i<data_len+3; ++i)
    {
        res_hi = 0;
        res_lo = 0;
        data[3] = data[2];
        data[2] = data[1];
        data[1] = data[0];
        if(i<data_len)
        {
        	data[0] = data_array[i];
        }
        else 
        {
		data[0] = 0;
	}        
	
        for(int j = 0 ;j<4;j++)
        {
            mul64(data[j], kernel_array[3-j], &hi[j], &lo[j]);
            res_hi += hi[j];
            res_lo += lo[j];
        }
        dest[i*2+1] = res_lo;
        dest[i*2] = res_hi;
    }

}
