#include <string.h>

void *memset(void *restrict dst, int c, size_t n) {
	
	
}

size_t strnlen(const char *restrict s, size_t maxlen) {
#error Not yet implemented
}
