#include"../include/sbi.h"
int main()
{
    sbi_ecall(0x4442434e, 2, 0x30, 0, 0, 0, 0, 0);
    return 0;
}