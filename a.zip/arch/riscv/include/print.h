#ifndef __PRINT_H__
#define __PRINT_H__

void puts(const char *s);  // 输出字符串 s
void puti(int i);          // 输出整数 i

#endif
