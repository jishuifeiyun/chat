#include <print.h>
#include <sbi.h>

void puts(const char *s) {
#error Not yet implemented
}

void puti(int i) {
#error Not yet implemented
}
